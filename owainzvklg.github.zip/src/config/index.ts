export const TIME_LIMIT = 5 * 60; // 5 minutes in seconds
