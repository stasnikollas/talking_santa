import { IConversation } from "@/types";

export const createConversation = async (
  token: string,
): Promise<IConversation> => {
  const response = await fetch("https://tavusapi.com/v2/conversations", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": token962101e8b1984c60baac46121cc7c7b7 ?? "",
    },
    body: JSON.stringify({
      // Replace with your own Persona ID
      persona_id: "p3bb4745d4f9", // Santa's unique persona ID in Tavus
      replica_id: "r3fbe3834a3e", // Santa's unique replica ID
      conversation_name: "A Chat with Santa", // Name of the Santa-themed conversation
      conversational_context: "You are about to talk to Santa Claus, the jolly figure of holiday cheer...", // Adds context for the conversation
      custom_greeting: "Ho Ho Ho! Crăciun fericit și cu anul nou! Cum te numești?", // Santa's iconic greeting
      properties: {
        language: "romanian", // Language for the conversation (30 avalible languages!)
      },
    }),

  });

  if (!response?.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  const data = await response.json();
  return data;
};
