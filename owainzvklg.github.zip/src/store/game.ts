import { atom } from "jotai";

export const niceScoreAtom = atom<number>(0);
export const naughtyScoreAtom = atom<number>(0);
